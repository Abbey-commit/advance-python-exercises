from django.apps import AppConfig


class RiddlesConfig(AppConfig):
    name = 'riddles'
